python /Users/$USER/chords-App/main.py
osascript -e 'tell application "Terminal" to close first window' & exit
